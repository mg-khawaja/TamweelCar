﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TamweelyMobileApp.Helpers
{
    public enum AuthPage
    {
        Login,
        Signup,
        EditProfile
    }
}
