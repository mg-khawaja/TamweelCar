﻿using System.Collections.Generic;
using System.Linq;

namespace TamweelyMobileApp.Helpers
{
    public class CountryCode
    {
        public string name { get; set; }
        public string dial_code { get; set; }
        public string code { get; set; }
    }
}