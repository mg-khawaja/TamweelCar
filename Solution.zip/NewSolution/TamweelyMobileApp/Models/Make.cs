﻿using System;

namespace TamweelyMobileApp.Models
{
    public class Make
    {
        public int Id { get; set; }
        public string Description { get; set; }
    }
}