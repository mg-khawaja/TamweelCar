﻿using System;

namespace TamweelyMobileApp.Models
{
    public enum ConfigType
    {
        Interest,
        Insurance,
        DownPayment,
        LastPayment,
        NoOfMonths
    }
}